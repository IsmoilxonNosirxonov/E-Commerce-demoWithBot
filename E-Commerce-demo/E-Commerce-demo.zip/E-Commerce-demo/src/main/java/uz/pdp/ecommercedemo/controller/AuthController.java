package uz.pdp.ecommercedemo.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import uz.pdp.ecommercedemo.domain.entity.UserEntity;
import uz.pdp.ecommercedemo.domain.dto.request.AuthDto;
import uz.pdp.ecommercedemo.domain.dto.request.UserRequest;
import uz.pdp.ecommercedemo.service.UserService;


@Controller
@RequestMapping("/auth")
@RequiredArgsConstructor
public class AuthController {

    private final UserService userService;

//    @GetMapping("/login")
//    public String loginPage(Model model) {
//        return "login";
//    }
//    @PostMapping("/login")
//    public String login(
//            @ModelAttribute AuthDto authDto,
//            Model model
//    ) {
//        currentUser= userService.login(authDto);
//        model.addAttribute("login", currentUser);
//        model.addAttribute("allUsers", userService.getAll());
//        return "menu";
//    }

    @GetMapping("/reg")
    public String registerPage() {
        return "register";
    }

    @PostMapping("/register")
    public String register(
            @ModelAttribute UserRequest userCreateDto, Model model
    ) {
        userService.save(userCreateDto);
        model.addAttribute("users", userService.getAll());
        model.addAttribute("message","User successfully added!");
        return "menu";
    }

}
