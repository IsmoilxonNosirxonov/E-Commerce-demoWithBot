package uz.pdp.ecommercedemo.service;

import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import uz.pdp.ecommercedemo.domain.dto.BaseResponse;
import uz.pdp.ecommercedemo.domain.dto.request.BasketCreateDto;
import uz.pdp.ecommercedemo.domain.entity.BasketEntity;
import uz.pdp.ecommercedemo.repository.BasketRepository;

import java.sql.SQLException;
import java.util.List;
import java.util.Optional;


@Service
@RequiredArgsConstructor
public class BasketService implements BaseService<BasketEntity, BasketCreateDto> {

    private final UserService userService;

    private final BasketRepository basketRepository;

    private final ModelMapper modelMapper;

    @Override
    public BasketEntity save(BasketCreateDto createDto) {
        return null;
    }

    @Override
    public void delete(Long id) {

    }

    @Override
    public BasketEntity update(BasketCreateDto createDto, Long id) {
        return null;
    }

    @Override
    public BasketEntity getById(Long id) {
        return null;
    }

    @Override
    public List<BasketEntity> getAll() {
        return null;
    }


    public List<BasketEntity> getMyBaskets(Long userId){
        return basketRepository.findByUserId(userId);
    }
//
//    public BaseResponse<BasketEntity> removeMyBasket(Long userId){
//        try {
//            Optional<BasketEntity> basketEntity = basketRepository.deleteMyBasketById(userId);
//            return new BaseResponse<>("Success",200,basketEntity.get(),true);
//        }catch (Exception e) {
//            throw new RuntimeException(e);
//        }
//    }
//
    public List<BasketEntity> getUserBaskets(Long chatId) {
        return basketRepository.findByUserId(userService.findByChatId(chatId.toString()).getId());
    }
}
