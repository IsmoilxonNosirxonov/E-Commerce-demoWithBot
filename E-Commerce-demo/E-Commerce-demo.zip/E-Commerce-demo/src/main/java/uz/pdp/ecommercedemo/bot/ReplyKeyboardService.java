package uz.pdp.ecommercedemo.bot;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.InlineKeyboardMarkup;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.ReplyKeyboard;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.ReplyKeyboardMarkup;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.buttons.InlineKeyboardButton;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.buttons.KeyboardButton;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.buttons.KeyboardRow;
import uz.pdp.ecommercedemo.domain.entity.BasketEntity;
import uz.pdp.ecommercedemo.domain.entity.CategoryEntity;
import uz.pdp.ecommercedemo.domain.entity.OrderEntity;
import uz.pdp.ecommercedemo.domain.entity.ProductEntity;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;


@Service
@RequiredArgsConstructor
public class ReplyKeyboardService {

    public ReplyKeyboard requestContact() {
        ReplyKeyboardMarkup markup = new ReplyKeyboardMarkup();
        KeyboardRow keyboardRow = new KeyboardRow();
        KeyboardButton button = new KeyboardButton("Please share phone number 📞");
        button.setRequestContact(true);
        keyboardRow.add(button);
        markup.setResizeKeyboard(true);
        markup.setKeyboard(List.of(keyboardRow));
        return markup;
    }

    public ReplyKeyboardMarkup mainMenu() {
        ReplyKeyboardMarkup replyKeyboardMarkup = new ReplyKeyboardMarkup();
        replyKeyboardMarkup.setResizeKeyboard(true);
        List<KeyboardRow> keyboardRows = new ArrayList<>();

        KeyboardRow row = new KeyboardRow();
        row.add("📋 Categories");
        row.add("🧺 Basket");
        keyboardRows.add(row);

        row = new KeyboardRow();
        row.add("📪 Orders");
        row.add("🗒️ History");
        keyboardRows.add(row);

        row = new KeyboardRow();
        row.add("💰️ Get balance");
        row.add("💸 Add balance");
        keyboardRows.add(row);

        replyKeyboardMarkup.setKeyboard(keyboardRows);
        return replyKeyboardMarkup;
    }

    public ReplyKeyboard categoryInlineKeyboardMarkup(
            List<CategoryEntity> categories) {
        List<List<InlineKeyboardButton>> buttons = new LinkedList<>();
        for (CategoryEntity category : categories) {
            buttons.add(createCategoryButton(category));
        }
        InlineKeyboardMarkup inlineKeyboardMarkup = new InlineKeyboardMarkup();
        inlineKeyboardMarkup.setKeyboard(buttons);
        return inlineKeyboardMarkup;
    }

    private List<InlineKeyboardButton> createCategoryButton(
            CategoryEntity category) {
        InlineKeyboardButton button = new InlineKeyboardButton(category.getName());
        button.setCallbackData(category.getId().toString());
        return List.of(button);
    }

    public InlineKeyboardMarkup parseProductsIntoInlineKeyboardMarkup(
            List<ProductEntity> products) {
        List<List<InlineKeyboardButton>> buttons = new LinkedList<>();

        for (ProductEntity product : products) {
            buttons.add(createProductButton(product));
        }
        InlineKeyboardMarkup inlineKeyboardMarkup = new InlineKeyboardMarkup();
        inlineKeyboardMarkup.setKeyboard(buttons);
        return inlineKeyboardMarkup;
    }

    private List<InlineKeyboardButton> createProductButton(ProductEntity product) {
        InlineKeyboardButton button = new InlineKeyboardButton(product.getName());
        button.setCallbackData(product.getId().toString());
        return List.of(button);
    }

    public InlineKeyboardMarkup createNumberButton(Long productId) {
        List<List<InlineKeyboardButton>> buttons = new LinkedList<>();
        List<InlineKeyboardButton> rows = new LinkedList<>();
        InlineKeyboardButton button = new InlineKeyboardButton("1️⃣");
        button.setCallbackData("1 " + productId);
        rows.add(button);
        button = new InlineKeyboardButton("2️⃣");
        button.setCallbackData("2 " + productId);
        rows.add(button);
        button = new InlineKeyboardButton("3️⃣");
        button.setCallbackData("3 " + productId);
        rows.add(button);
        buttons.add(rows);
        rows = new LinkedList<>();
        button = new InlineKeyboardButton("4️⃣");
        button.setCallbackData("4 " + productId);
        rows.add(button);
        button = new InlineKeyboardButton("5️⃣");
        button.setCallbackData("5 " + productId);
        rows.add(button);
        button = new InlineKeyboardButton("6️⃣");
        button.setCallbackData("6 " + productId);
        rows.add(button);
        buttons.add(rows);
        rows = new LinkedList<>();
        button = new InlineKeyboardButton("7️⃣");
        button.setCallbackData("7 " + productId);
        rows.add(button);
        button = new InlineKeyboardButton("8️⃣");
        button.setCallbackData("8 " + productId);
        rows.add(button);
        button = new InlineKeyboardButton("9️⃣");
        button.setCallbackData("9 " + productId);
        rows.add(button);
        buttons.add(rows);
        InlineKeyboardMarkup inline = new InlineKeyboardMarkup();
        inline.setKeyboard(buttons);
        return inline;
    }

    public ReplyKeyboard parseBasketIntoInlineKeyboardMarkup(List<BasketEntity> baskets) {
        List<List<InlineKeyboardButton>> buttons = new LinkedList<>();

        for (BasketEntity basket : baskets) {
            buttons.add(createBasketButton(basket));
        }
        InlineKeyboardMarkup inlineKeyboardMarkup = new InlineKeyboardMarkup();
        inlineKeyboardMarkup.setKeyboard(buttons);
        return inlineKeyboardMarkup;
    }

    private List<InlineKeyboardButton> createBasketButton(BasketEntity basket) {
        InlineKeyboardButton button = new InlineKeyboardButton(/*basket.getProducts().getName()*/);
        button.setCallbackData(basket.getId().toString());
        return List.of(button);
    }

    public InlineKeyboardMarkup getBasketInlineKeyboardMarkup(Long basketId) {
        List<List<InlineKeyboardButton>> buttons = new LinkedList<>();
        List<InlineKeyboardButton> rows = new LinkedList<>();
        InlineKeyboardButton button = new InlineKeyboardButton("➕");
        button.setCallbackData("1 " + basketId);
        rows.add(button);

        button = new InlineKeyboardButton("➖");
        button.setCallbackData("-1 " + basketId);
        rows.add(button);

        buttons.add(rows);

        rows = new LinkedList<>();
        button = new InlineKeyboardButton("❌ Remove");
        button.setCallbackData("0 " + basketId);
        rows.add(button);

        button = new InlineKeyboardButton("🚢 Order");
        button.setCallbackData("2 " + basketId);
        rows.add(button);

        buttons.add(rows);
        InlineKeyboardMarkup inline = new InlineKeyboardMarkup();
        inline.setKeyboard(buttons);
        return inline;
    }

    public ReplyKeyboard parseOrdersIntoInlineKeyboardMarkup(List<OrderEntity> orders) {
        List<List<InlineKeyboardButton>> buttons = new LinkedList<>();
        for (OrderEntity order : orders) {
            buttons.add(createOrderButton(order));
        }
        InlineKeyboardMarkup inlineKeyboardMarkup = new InlineKeyboardMarkup();
        inlineKeyboardMarkup.setKeyboard(buttons);
        return inlineKeyboardMarkup;
    }

    private List<InlineKeyboardButton> createOrderButton(OrderEntity order) {
        InlineKeyboardButton button = new InlineKeyboardButton(getOrderInfo(order));
        button.setCallbackData(order.getId().toString());
        return List.of(button);
    }

    private String getOrderInfo(OrderEntity order) {
        ProductEntity product = order.getProduct();
        return String.format("""
                Name: %s
                Type: %s
                Total price: %s
                Amount: %s
                
                PRESS THIS IF YOU WANT TO CANCEL ORDER
                """, product.getName(), order.getTotalPrice(),
                product.getCategory().getName(), order.getAmount());
    }
}

