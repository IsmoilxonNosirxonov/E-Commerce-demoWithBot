package uz.pdp.ecommercedemo.service;

import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import uz.pdp.ecommercedemo.common.AlreadyExistsException;
import uz.pdp.ecommercedemo.common.DataNotFoundException;
import uz.pdp.ecommercedemo.domain.dto.BaseResponse;
import uz.pdp.ecommercedemo.domain.entity.CategoryEntity;
import uz.pdp.ecommercedemo.domain.entity.ProductEntity;
import uz.pdp.ecommercedemo.domain.dto.request.ProductCreateDto;
import uz.pdp.ecommercedemo.repository.ProductRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


@Service
@RequiredArgsConstructor
public class ProductService implements BaseService<ProductEntity, ProductCreateDto> {

    private final ProductRepository productRepository;

    private final ModelMapper modelMapper;

    @Override
    public ProductEntity save(ProductCreateDto createDto) {
        ProductEntity productEntity = modelMapper.map(createDto, ProductEntity.class);
        try {
            return productRepository.save(productEntity);
        } catch (Exception e) {
            throw new AlreadyExistsException("Same name already exists!");
        }
    }

    @Override
    public void delete(Long id) {
        productRepository.deleteById(id);
    }

    @Override
    public ProductEntity update(ProductCreateDto createDto, Long id) {
        try {
            Optional<ProductEntity> entity = productRepository.findById(id);
            entity.get().setName(createDto.getName());
            entity.get().setPrice(createDto.getPrice());
            return productRepository.save(entity.get());
        } catch (Exception e) {
            throw new DataNotFoundException("This product does not exists!");
        }
    }

    @Override
    public ProductEntity getById(Long id) {
        if (productRepository.findById(id).isPresent()) {
            return productRepository.findById(id).get();
        } else {
            throw new DataNotFoundException("Product not found");
        }
    }

    @Override
    public List<ProductEntity> getAll() {
        return productRepository.findAll();
    }

    public List<ProductEntity> getProductsByCategoryId(Long categoryId) {
        List<ProductEntity> productEntityList=new ArrayList<>();
        for (ProductEntity product: productRepository.findAll()){
            if (product.getCategory().getId().equals(categoryId)){
                productEntityList.add(product);
            }
        }
        return productEntityList;
    }
}