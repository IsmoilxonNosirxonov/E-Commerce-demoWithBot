package uz.pdp.ecommercedemo.repository;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import uz.pdp.ecommercedemo.domain.entity.UserEntity;
import uz.pdp.ecommercedemo.domain.entity.enums.UserRole;
import uz.pdp.ecommercedemo.domain.entity.enums.UserState;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
class UserRepositoryTest {

    @Autowired
    UserRepository userRepository;

    @Test
    void findByUsernameTest() {
        UserEntity user = UserEntity.builder()
                .username("test")
                .name("test name")
                .password("password")
                .balance(2.0)
                .state(UserState.NEW)
                .roles(List.of(UserRole.USER))
                .build();
        userRepository.save(user);

        Optional<UserEntity> test = userRepository.findByUsername("test");

       assertTrue(test.isPresent());
    }
}