package uz.pdp.ecommercedemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ECommerceDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(ECommerceDemoApplication.class, args);
    }

}
