package uz.pdp.ecommercedemo.service;

import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.telegram.telegrambots.meta.api.objects.User;
import uz.pdp.ecommercedemo.common.AlreadyExistsException;
import uz.pdp.ecommercedemo.common.AuthenticationException;
import uz.pdp.ecommercedemo.common.DataNotFoundException;
import uz.pdp.ecommercedemo.domain.dto.BaseResponse;
import uz.pdp.ecommercedemo.domain.dto.request.UserStateDto;
import uz.pdp.ecommercedemo.domain.entity.UserEntity;
import uz.pdp.ecommercedemo.domain.dto.request.AuthDto;
import uz.pdp.ecommercedemo.domain.dto.request.UserRequest;
import uz.pdp.ecommercedemo.domain.entity.enums.UserRole;
import uz.pdp.ecommercedemo.domain.entity.enums.UserState;
import uz.pdp.ecommercedemo.repository.UserRepository;

import java.util.*;

@Service
@RequiredArgsConstructor
public class UserService implements BaseService<UserEntity, UserRequest> {

    private final UserRepository userRepository;

    private final ModelMapper modelMapper;

    private final PasswordEncoder passwordEncoder;

    @Override
    public UserEntity save(UserRequest userRequest) {
        UserEntity userEntity = modelMapper.map(userRequest, UserEntity.class);
        try {
            userEntity.setPassword(passwordEncoder.encode(userEntity.getPassword()));
            userEntity.setState(UserState.START);
            userEntity.setRoles(userEntity.getRoles());
            return userRepository.save(userEntity);
        } catch (Exception e) {
            throw new AlreadyExistsException("Same username already exists!");
        }
    }


    @Override
    public void delete(Long id) {
        userRepository.deleteById(id);
    }

    @Override
    public UserEntity update(UserRequest request, Long id) {
        try {
            Optional<UserEntity> userEntity = userRepository.findById(id);
            userEntity.get().setName(request.getName());
            userEntity.get().setUsername(request.getUsername());
            userEntity.get().setBalance(request.getBalance());
            return userRepository.save(userEntity.get());
        } catch (Exception e) {
            throw new DataNotFoundException("This user does not exists");
        }
    }

    @Override
    public UserEntity getById(Long id) {
        if (userRepository.findById(id).isPresent()) {
            return userRepository.findById(id).get();
        } else {
            throw new DataNotFoundException("User Not Found!");
        }
    }

    public UserEntity findByChatId(String chatId){
        if (userRepository.findByChatId(chatId).isPresent()){
            return userRepository.findByChatId(chatId).get();
        }
        throw new DataNotFoundException("User Not Found!");
    }

    @Override
    public List<UserEntity> getAll() {
        List<UserEntity> users = new ArrayList<>();
        for (UserEntity user : userRepository.findAll()) {
            if (!user.getRoles().contains(UserRole.SUPER_ADMIN)) {
                users.add(user);
            }
        }
        return users;
    }

    public UserEntity login(AuthDto authDto) {
        UserEntity userEntity = userRepository.findByUsername(authDto.getUsername()).orElseThrow(() -> {
            throw new AuthenticationException("Wrong username and/or password");
        });
        if (!passwordEncoder.matches(authDto.getPassword(), userEntity.getPassword())) {
            throw new AuthenticationException("Wrong username and/or password");
        }
        Collection<? extends GrantedAuthority> authorities = userEntity.getAuthorities();
        Authentication authentication = new UsernamePasswordAuthenticationToken(
                userEntity.getUsername(),
                null,
                authorities
        );
        SecurityContextHolder.getContext().setAuthentication(authentication);
        return userEntity;
    }


    public UserEntity getByUsername(String username) {
        return userRepository.findByUsername(username).orElseThrow(() -> {
            throw new DataNotFoundException("User Not Found!");
        });
    }

    public void updateUserState(Long chatId, UserState state) {
        UserEntity userEntity = userRepository.findByChatId(chatId.toString()).orElseThrow(() -> new DataNotFoundException("User don`t found"));
        userEntity.setState(state);
        userRepository.save(userEntity);
    }

    public BaseResponse<UserState> getUserState(Long chatId){
        UserEntity userEntity = userRepository.findByChatId(chatId.toString()).orElseThrow(() -> {
            throw new DataNotFoundException("This user is not found");
        });
        return new BaseResponse<>("success",200,userEntity.getState(),true);
    }

    public void saveBotUser(Long chatId, User user) {
        UserEntity userEntity=UserEntity.builder()
                .name(user.getFirstName()+" "+user.getLastName())
                .username(user.getUserName())
                .chatId(chatId.toString())
                .balance(0.0)
                .password("777")
                .state(UserState.NEW)
                .build();
        userRepository.save(userEntity);
    }

    public Double getUserBalance(Long chatId) {
        UserEntity userEntity = userRepository.findByChatId(chatId.toString()).orElseThrow();
        return userEntity.getBalance();
    }
}