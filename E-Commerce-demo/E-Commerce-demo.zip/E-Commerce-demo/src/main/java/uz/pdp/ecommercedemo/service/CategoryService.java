package uz.pdp.ecommercedemo.service;

import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import uz.pdp.ecommercedemo.common.AlreadyExistsException;
import uz.pdp.ecommercedemo.common.DataNotFoundException;
import uz.pdp.ecommercedemo.domain.entity.CategoryEntity;
import uz.pdp.ecommercedemo.domain.dto.request.CategoryCreateDto;
import uz.pdp.ecommercedemo.repository.CategoryRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


@Service
@RequiredArgsConstructor
public class CategoryService implements BaseService<CategoryEntity, CategoryCreateDto> {

    private final CategoryRepository categoryRepository;

    private final ModelMapper modelMapper;

    @Override
    public CategoryEntity save(CategoryCreateDto createDto) {
        CategoryEntity entity = modelMapper.map(createDto, CategoryEntity.class);
        try {
            return categoryRepository.save(entity);
        } catch (Exception e) {
            throw new AlreadyExistsException("Same name already exists!");
        }
    }

    @Override
    public void delete(Long id) {
        for (CategoryEntity category : categoryRepository.findAll()) {
            if(category.getParentId()!=null && category.getParentId().equals(id)){
                categoryRepository.deleteById(category.getId());
            }
        }
        categoryRepository.deleteById(id);
    }

    @Override
    public CategoryEntity update(CategoryCreateDto createDto, Long id) {
        try {
            Optional<CategoryEntity> entity = categoryRepository.findById(id);
            entity.get().setName(createDto.getName());
            return categoryRepository.save(entity.get());
        } catch (Exception e) {
            throw new DataNotFoundException("This category does not exists");
        }
    }

    @Override
    public CategoryEntity getById(Long id) {
        if (categoryRepository.findById(id).isPresent()) {
            return categoryRepository.findById(id).get();
        } else {
            throw new DataNotFoundException("Category not found");
        }
    }

    @Override
    public List<CategoryEntity> getAll() {
        return categoryRepository.findAll();
    }

    public List<CategoryEntity> getChildCategories() {
        List<CategoryEntity> childCategories=new ArrayList<>();
        for (CategoryEntity category : categoryRepository.findAll()) {
            if(category.getParentId()!=null){
                childCategories.add(category);
            }
        }
        return childCategories;
    }

    public void addChildCategory(Long parentId, CategoryCreateDto childCategoryDTO) {
        CategoryEntity childCategory=CategoryEntity.builder()
                .name(childCategoryDTO.getName())
                .parentId(parentId)
                .build();
        categoryRepository.save(childCategory);
    }
}