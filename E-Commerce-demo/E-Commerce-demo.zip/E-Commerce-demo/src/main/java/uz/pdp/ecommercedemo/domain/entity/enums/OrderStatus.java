package uz.pdp.ecommercedemo.domain.entity.enums;

public enum OrderStatus {

    CREATED,
    PROCESSING,
    SHIPPED,
    DELIVERED,
    FAILED

}
