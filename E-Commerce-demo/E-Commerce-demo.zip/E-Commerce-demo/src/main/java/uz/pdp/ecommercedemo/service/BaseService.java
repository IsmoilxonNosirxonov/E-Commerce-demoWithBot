package uz.pdp.ecommercedemo.service;

import org.springframework.stereotype.Service;

import java.util.List;


/**
 * @param <E> E entity
 * @param <CD> CD create dto
 * @author Tojiahmedov Nodir
 */

@Service
public interface BaseService<E, CD> {

    E save(CD createDto);
    void delete(Long id);
    E update(CD createDto, Long id);
    E getById(Long id);
    List<E> getAll();

}
