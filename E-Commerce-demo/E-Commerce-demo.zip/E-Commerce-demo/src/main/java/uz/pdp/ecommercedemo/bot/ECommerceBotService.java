package uz.pdp.ecommercedemo.bot;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.telegram.telegrambots.meta.api.methods.send.SendMessage;
import org.telegram.telegrambots.meta.api.methods.updatingmessages.EditMessageText;
import org.telegram.telegrambots.meta.api.objects.User;
import uz.pdp.ecommercedemo.domain.dto.BaseResponse;
import uz.pdp.ecommercedemo.domain.entity.*;
import uz.pdp.ecommercedemo.domain.entity.enums.UserState;
import uz.pdp.ecommercedemo.service.*;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ECommerceBotService {

    private final UserService userService;
    private final ReplyKeyboardService keyboardService;
    private final CategoryService categoryService;
    private final ReplyKeyboardService replyKeyboardService;
    private final ProductService productService;
    private final BasketService basketService;
    private final OrderService orderService;

    public UserState checkState(Long chatId) {
        BaseResponse<UserState> response = userService.getUserState(chatId);
        if (response.getStatus() == 200) {
            return response.getData();
        }
        return UserState.NEW;
    }

    public SendMessage shareContact(String chatId) {
        SendMessage sendMessage = new SendMessage(chatId.toString(), "Please register yourself");
        sendMessage.setReplyMarkup(keyboardService.requestContact());
        return sendMessage;
    }

    public SendMessage registerUser(Long chatId, User user) {
        userService.saveBotUser(chatId, user);
        SendMessage sendMessage = new SendMessage(
                chatId.toString(), user.getFirstName() + " has been saved");
        sendMessage.setReplyMarkup(keyboardService.mainMenu());
        return sendMessage;
    }


    public UserState navigateMenu(String request, Long chatId) {
        UserState userState;
        switch (request) {
            case "📋 Categories" -> userState = UserState.CATEGORIES;
            case "🧺 Basket" -> userState = UserState.BASKETS;
            case "📪 Orders" -> userState = UserState.ORDERS;
            case "🗒️ History" -> userState = UserState.HISTORIES;
            case "💰️ Get balance" -> userState = UserState.GET_BALANCE;
            case "💸 Add balance" -> userState = UserState.ADD_BALANCE;
            default -> userState = UserState.IDLE;
        }
        userService.updateUserState(chatId, userState);
        return userState;
    }

    public SendMessage getCategories(Long chatId) {
        SendMessage sendMessage = new SendMessage();
        sendMessage.setChatId(chatId.toString());
        List<CategoryEntity> categories = categoryService.getAll();
        if (categories.isEmpty()){
            sendMessage.setText("There is no categories");
        }else {
            sendMessage.setReplyMarkup(replyKeyboardService
                    .categoryInlineKeyboardMarkup(categories));
            sendMessage.setText("categories");
        }
        return sendMessage;
    }
    public SendMessage getBaskets(Long chatId) {
        SendMessage message = new SendMessage();
        message.setChatId(chatId.toString());
        List<BasketEntity> userBaskets = basketService.getUserBaskets(chatId);

        if (userBaskets.isEmpty()){
            message.setText("Your basket is empty");
        }else {
            userService.updateUserState(chatId, UserState.BASKETS);
            message.setText("basket");
            message.setReplyMarkup(replyKeyboardService
                    .parseBasketIntoInlineKeyboardMarkup(userBaskets));
        }
        return message;
    }

    public EditMessageText getProductsByCategoryId(Long categoryId, Long chatId, Integer messageId) {
        EditMessageText sendMessage = new EditMessageText();
        sendMessage.setMessageId(messageId);
        sendMessage.setChatId(chatId.toString());
        sendMessage.setText("products");
        List<ProductEntity> products =
                productService.getProductsByCategoryId(categoryId);
        if (products.isEmpty()){
            sendMessage.setText("There is no products by this category");
        }else {
            userService.updateUserState(chatId, UserState.PRODUCTS);
            sendMessage.setReplyMarkup(replyKeyboardService
                    .parseProductsIntoInlineKeyboardMarkup(products));
        }
        return sendMessage;
    }

    public EditMessageText getProductById(Long productId, Long chatId, Integer messageId) {
        userService.updateUserState(chatId, UserState.PRODUCT);
        ProductEntity product = productService.getById(productId);
        EditMessageText sendMessage = new EditMessageText(getProductInfo(product));
        sendMessage.setChatId(chatId.toString());
        sendMessage.setMessageId(messageId);
        sendMessage.setReplyMarkup(replyKeyboardService.createNumberButton(product.getId()));
        return sendMessage;
    }

    private String getProductInfo(ProductEntity product){
        return String.format("""
                Name: %s
                Price: %s
                Total mount: %s
                Type: %s

                Press any numbers below 👇🏻""", product.getName(),
                product.getPrice(), product.getQuantity(), product.getCategory().getName());
    }

//    public EditMessageText addProductToBasket(String data, Long chatId, Integer messageId) {
//        basketService.save(data, chatId);
//        EditMessageText message = new EditMessageText("Product has been added to your basket");
//        message.setChatId(chatId.toString());
//        message.setMessageId(messageId);
//        return message;
//    }

    public SendMessage getMenu(Long chatId) {
        SendMessage sendMessage = new SendMessage(
                chatId.toString(), "Menu");
        sendMessage.setReplyMarkup(keyboardService.mainMenu());
        userService.updateUserState(chatId, UserState.REGISTERED);
        return sendMessage;
    }

    public EditMessageText getBasketById(Long basketId, Long chatId, Integer messageId) {
        userService.updateUserState(chatId, UserState.BASKET);
        BasketEntity basket = basketService.getById(basketId);
        EditMessageText message = new EditMessageText(getBasketInfo(basket));
        message.setChatId(chatId.toString());
        message.setMessageId(messageId);
        message.setReplyMarkup(replyKeyboardService.getBasketInlineKeyboardMarkup(basket.getId()));
        return message;
    }

    private String getBasketInfo(BasketEntity basket) {
        ProductEntity product = basket.getProduct();
        return String.format("""
                Name: %s
                Price: %s
                Amount: %s
                Type: %s
                Total price: %s

                Press any numbers below 👇🏻""", product.getName(),
                product.getPrice(), basket.getAmount(), product.getCategory().getName(),
                product.getPrice()*basket.getAmount());
    }

//    public EditMessageText modifyBasket(String data, Long chatId, Integer messageId) {
//        EditMessageText message = new EditMessageText();
//        message.setChatId(chatId.toString());
//        String[] split = data.split(" ");
//        int status = Integer.parseInt(split[0]);
//        Long basketId = Long.valueOf(split[1]);
//        message.setMessageId(messageId);
//
//        if (status==0){
//            basketService.delete(basketId);
//            message.setText("Basket has been deleted");
//        } else if (status==2) {
//            BaseResponse<BasketGetResponse> response = orderService
//                    .orderProduct(basketId);
//            if (response.getStatus()==200){
//                message.setText(response.getMessage());
//            }else {
//                BasketGetResponse basket = response.getData();
//                String basketInfo = getBasketInfo(basket) + "  " + response.getMessage();
//                message.setText(basketInfo);
//                message.setReplyMarkup(replyKeyboardService
//                        .getBasketInlineKeyboardMarkup(basketId));
//            }
//        } else {
//            BaseResponse<BasketGetResponse> response = basketService
//                    .modifyBasket(status, basketId);
//            BasketGetResponse basket = response.getData();
//
//            String basketInfo = getBasketInfo(basket) + "  " + response.getMessage();
//            message.setText(basketInfo);
//            message.setReplyMarkup(replyKeyboardService
//                    .getBasketInlineKeyboardMarkup(basketId));
//        }
//        return message;
//    }


    public SendMessage getOrders(Long chatId) {
        SendMessage message = new SendMessage();
        List<OrderEntity> orders = orderService
                .findUserOrders(chatId);
        if (orders.isEmpty()){
            message = getMenu(chatId);
            message.setText("Your order is empty");
        }else {
            message.setText("orders");
            message.setChatId(chatId.toString());
            message.setReplyMarkup(replyKeyboardService
                    .parseOrdersIntoInlineKeyboardMarkup(orders));
        }
        return message;
    }

    public SendMessage askUserToWriteBalance(Long chatId) {
        return new SendMessage(chatId.toString(), "Please write amount");
    }

    public SendMessage getUserBalance(Long chatId) {
        Double response = userService.getUserBalance(chatId);
        return new SendMessage(chatId.toString(), "Your balance: " + response);
    }

//    public SendMessage addBalance(String text, Long chatId) {
//        BaseResponse response = userService.addBalance(text, chatId);
//        userService.updateUserState(chatId, UserState.IDLE);
//        return new SendMessage(chatId.toString(), response.getMessage());
//    }

    public EditMessageText deleteUserOrder(Long orderId, Long chatId, Integer messageId) {
        orderService.delete(orderId);
        EditMessageText message = new EditMessageText("Order has been deleted");
        message.setMessageId(messageId);
        message.setChatId(chatId.toString());
        return message;
    }

}
