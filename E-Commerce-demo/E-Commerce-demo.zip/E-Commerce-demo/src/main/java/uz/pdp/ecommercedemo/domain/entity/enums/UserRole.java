package uz.pdp.ecommercedemo.domain.entity.enums;

public enum UserRole {

    SUPER_ADMIN,

    ADMIN,

    USER,

    ACCOUNTER;

}
