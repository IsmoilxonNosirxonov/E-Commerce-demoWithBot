package uz.pdp.ecommercedemo.common;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class CommonExceptionHandler {

    @ExceptionHandler(AuthenticationException.class)
    public String authenticationFailure(AuthenticationException e) {
        return e.getMessage();
    }

//    @ExceptionHandler(value = AlreadyExistsException.class)
//    public String handleDataNotFoundException(AlreadyExistsException e,
//                                              Model model){
//        model.addAttribute("message", e.getMessage());
//        return "auth";
//    }
    @ExceptionHandler(value = DataNotFoundException.class)
    public String handleDataNotFoundException(DataNotFoundException e,
                                              Model model){
        model.addAttribute("message", e.getMessage());
        return "auth";
    }

}
