package uz.pdp.ecommercedemo.service;

import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import uz.pdp.ecommercedemo.common.DataNotFoundException;
import uz.pdp.ecommercedemo.domain.dto.request.UserStateDto;
import uz.pdp.ecommercedemo.domain.entity.OrderEntity;
import uz.pdp.ecommercedemo.domain.dto.request.OrderCreateDto;
import uz.pdp.ecommercedemo.domain.entity.UserEntity;
import uz.pdp.ecommercedemo.repository.OrderRepository;
import java.util.List;


@Service
@RequiredArgsConstructor
public class OrderService implements BaseService<OrderEntity, OrderCreateDto> {

    private final OrderRepository orderRepostory;
    private final ModelMapper modelMapper;
    @Override
    public OrderEntity save(OrderCreateDto orderCreateDto) {
        return orderRepostory.save(modelMapper.map(orderCreateDto,OrderEntity.class));
    }

    @Override
    public void delete(Long id) {
        orderRepostory.deleteById(id);
    }

    @Override
    public OrderEntity update(OrderCreateDto createDto, Long id) {
//        try {
//            Optional<OrderEntity> entity = orderRepostory.findById(id);
//            entity.get().setProducts(createDto.getProducts());
//            entity.get().setTotalPrice(createDto.getTotalPrice());
//            entity.get().setBought(createDto.isBought());
//            return orderRepostory.save(entity.get());
//        } catch (Exception e) {
//            throw new DataNotFoundException("This order does not exists!");
//        }
        return null;
    }

    @Override
    public OrderEntity getById(Long id) {
        return orderRepostory.findById(id).get();
    }

    @Override
    public List<OrderEntity> getAll() {
        return orderRepostory.findAll();
    }



//    public void updateUserState(UserStateDto stateDTO) {
//        UserEntity userEntity = userRepository.findByChatId(stateDTO.chatId()).orElseThrow(() -> new DataNotFoundException("User don`t found"));
//        userEntity.setState(stateDTO.state());
//        userRepository.save(userEntity);
//    }

    public void updateStatus(OrderEntity order) {
        OrderEntity orderEntity = orderRepostory.findById(order.getId()).orElseThrow(() -> new DataNotFoundException("Order don`t found"));
        orderEntity.setStatus(order.getStatus());
        orderRepostory.save(orderEntity);
    }

    public List<OrderEntity> findUserOrders(Long chatId) {
        return orderRepostory.findByUserChatId(chatId);
    }
}
