package uz.pdp.ecommercedemo.domain.dto.request;

import lombok.*;
import uz.pdp.ecommercedemo.domain.entity.ProductEntity;
import uz.pdp.ecommercedemo.domain.entity.enums.OrderStatus;

import java.util.List;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class OrderCreateDto {
    private Long productId;
    private Long userId;
    private Integer amount;
    private Double totalPrice;
    private OrderStatus status;
}