package uz.pdp.ecommercedemo.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.modelmapper.ModelMapper;
import uz.pdp.ecommercedemo.domain.dto.request.UserRequest;
import uz.pdp.ecommercedemo.domain.entity.UserEntity;
import uz.pdp.ecommercedemo.domain.entity.enums.UserRole;
import uz.pdp.ecommercedemo.repository.UserRepository;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.doReturn;
import static org.mockito.MockitoAnnotations.initMocks;

class UserServiceTest {

    private UserRequest userRequest;

    private UserEntity userEntity;

    @Mock
    private UserRepository userRepository;

    @Mock
    private ModelMapper modelMapper;

    @InjectMocks
    private UserService userService;

    @BeforeEach
    void setUp() {
        initMocks(this);
        userRequest = UserRequest.builder().name("qwer1").username("qwer1").password("qwer1").roles(List.of(UserRole.USER)).build();
        userEntity = UserEntity.builder().name("qwer1").username("qwer1").password("qwer1").roles(List.of(UserRole.USER)).build();
    }

    @Test
    void saveTest() {
        doReturn(userEntity).when(modelMapper).map(userRequest, UserEntity.class);
        doReturn(userEntity).when(userRepository).save(userEntity);

        UserEntity save = userService.save(userRequest);
        assertEquals("qwer", save.getName());

    }
}