package uz.pdp.ecommercedemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ECommerceDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
